# ExcelExport

Use these files to create a Visualforce Page and Controller in your Org that will export a sample list of Opportunities.
Note, I've suffixed them .xml and .java respectively, but that is just so they can be nicely syntax highlighted on GitHub.
